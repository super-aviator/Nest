create trigger user_info_AFTER_INSERT
  after INSERT
  on user_info
  for each row
  BEGIN
	
    SELECT  max(user_id) INTO @user_id from user_info;
    
    INSERT INTO packet_info(packet_name) VALUES('我的好友');
    SET @id1=LAST_INSERT_ID();
    
    INSERT INTO packet_info(packet_name) VALUES('我的家人');
    SET @id2=LAST_INSERT_ID();
    
    INSERT INTO packet_info(packet_name) VALUES('我的亲人');
    SET @id3=LAST_INSERT_ID();
    
    INSERT INTO packet_info(packet_name) VALUES('我的朋友');
    SET @id4=LAST_INSERT_ID();
    
    INSERT INTO packet_info(packet_name) VALUES('我的老师');
    SET @id5=LAST_INSERT_ID();
    
    INSERT INTO packet_info(packet_name) VALUES('我的同学');
    SET @id6=LAST_INSERT_ID();
    
    INSERT INTO packet_info(packet_name) VALUES('我的室友');
    SET @id7=LAST_INSERT_ID();
    
    INSERT INTO user_packet_info(packet_id,user_id) VALUES
    (@id1,@user_id)
    ,(@id2,@user_id)
    ,(@id3,@user_id)
    ,(@id4,@user_id)
    ,(@id5,@user_id)
    ,(@id6,@user_id)
    ,(@id7,@user_id);
END;

